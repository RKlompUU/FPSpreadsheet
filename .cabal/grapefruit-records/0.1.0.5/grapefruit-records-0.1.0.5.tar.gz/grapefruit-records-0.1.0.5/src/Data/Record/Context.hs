module Data.Record.Context (

    ContextStyle,
    app

) where

    -- Data
    import Data.Record as Record

    -- Fixities
    infixr 0 `app`

    {-|
        The context consumer and context producer record styles.

        @ContextConnectorStyle /context/ 'Consumer'@ is the style of context consumer records with
        context @/context/@ and @ContextConnectorStyle /context/ 'Producer'@ is the style of context
        producer records with context @/context/@. Fields of context connector style records have
        the form @/name/ ::~~ /connectorGenerator/@.
    -}
    data ContextStyle context style

    instance (Style style) => Style (ContextStyle context style) where

        type K (ContextStyle context style) = K style

    type instance Value (ContextStyle context style) sort = context -> Value style sort

    {-|
        Applies all values of a context connector record to a given context to form an ordinary
        context record.
    -}
    app :: (Style style, Record (K style) record)
        => record (ContextStyle context style)
        -> context
        -> record style
    app contextRecord context = Record.map transformer contextRecord where

        transformer      = encase (TransformerPiece (\valInContext -> valInContext context))
