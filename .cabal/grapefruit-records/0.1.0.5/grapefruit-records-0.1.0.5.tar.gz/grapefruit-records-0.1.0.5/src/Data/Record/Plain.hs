module Data.Record.Plain (

    PlainKind,
    Forall (PlainForall),
    PlainStyle

) where

    -- Data
    import Data.Record as Record

    data PlainKind

    instance Kind PlainKind where

        data Forall PlainKind piece = PlainForall (forall val. piece val)

        encase piece = PlainForall piece

    instance Sort PlainKind val where

        specialize (PlainForall piece) = piece

    data PlainStyle

    instance Style PlainStyle where

        type K PlainStyle = PlainKind

    type instance Value PlainStyle val = val
